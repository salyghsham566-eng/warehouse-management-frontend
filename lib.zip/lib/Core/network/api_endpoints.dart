class ApiEndpoints {
  ApiEndpoints._();
//التعديل 
  static const String baseUrl =
      'https://example.com/api/v1';

  static const String companies = '/companies';
  static const String pharmacies = '/pharmacies';
  static const String orders = '/orders';
  static const String collectionPharmacies =
      '/collection/pharmacies';
      static String collectionPharmacyDetails(
  String pharmacyId,
) {
  return '/collection/pharmacies/${Uri.encodeComponent(pharmacyId)}';
}
static const String collectionPayments =
    '/collection/payments';
    static String collectionPaymentDetails(
  String paymentId,
) {
  return '/collection/payments/'
      '${Uri.encodeComponent(paymentId)}';
}
}