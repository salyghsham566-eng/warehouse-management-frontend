import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:image_picker/image_picker.dart';
import 'package:project_2/Core/di/injection_container.dart';
import 'package:project_2/Core/theme/app_colors.dart';
import 'package:project_2/Features/auth/bloc/collection_payment_form_bloc.dart';
import 'package:project_2/Features/auth/bloc/collection_payment_form_event.dart';
import 'package:project_2/Features/auth/bloc/collection_payment_form_state.dart';
import 'package:project_2/Features/auth/data/models/2pharmacy_model.dart';
import 'package:project_2/Features/auth/data/models/collection_payment_model.dart';

class CollectionPaymentFormPage
    extends StatelessWidget {
  const CollectionPaymentFormPage({
    required this.pharmacy,
    super.key,
  });

  final CollectionPharmacyModel pharmacy;

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) =>
          sl<CollectionPaymentFormBloc>(
        param1: pharmacy,
      ),
      child: _CollectionPaymentFormView(
        pharmacy: pharmacy,
      ),
    );
  }
}

class _CollectionPaymentFormView
    extends StatefulWidget {
  const _CollectionPaymentFormView({
    required this.pharmacy,
  });

  final CollectionPharmacyModel pharmacy;

  @override
  State<_CollectionPaymentFormView>
      createState() =>
          _CollectionPaymentFormViewState();
}

class _CollectionPaymentFormViewState
    extends State<_CollectionPaymentFormView> {
  final GlobalKey<FormState> _formKey =
      GlobalKey<FormState>();

  final TextEditingController _amountController =
      TextEditingController();

  final TextEditingController _notesController =
      TextEditingController();

  final ImagePicker _imagePicker = ImagePicker();

  @override
  void dispose() {
    _amountController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: BlocConsumer<
          CollectionPaymentFormBloc,
          CollectionPaymentFormState>(
        listener: _paymentListener,
        builder: (context, state) {
          return Scaffold(
            backgroundColor:
                AppColors.background,
            appBar: AppBar(
              backgroundColor:
                  AppColors.background,
              surfaceTintColor:
                  Colors.transparent,
              elevation: 0,
              centerTitle: true,
              title: const Text(
                'تسجيل دفعة',
                style: TextStyle(
                  color: AppColors.textPrimary,
                  fontSize: 20,
                  fontWeight: FontWeight.w800,
                ),
              ),
              leading: IconButton(
                onPressed: state.isSubmitting
                    ? null
                    : () {
                        Navigator.pop(context);
                      },
                icon: const Icon(
                  Icons.arrow_forward,
                  color: AppColors.textPrimary,
                ),
              ),
            ),
            body: SafeArea(
              top: false,
              child: Form(
                key: _formKey,
                child: ListView(
                  padding:
                      const EdgeInsetsDirectional
                          .fromSTEB(
                    20,
                    12,
                    20,
                    30,
                  ),
                  children: [
                    _PharmacyCard(
                      pharmacy: widget.pharmacy,
                    ),

                    const SizedBox(height: 15),

                    _BalanceSection(
                      officialBalance:
                          state.officialBalance,
                      expectedBalance:
                          state.expectedBalance,
                    ),

                    const SizedBox(height: 15),

                    _SectionCard(
                      title: 'بيانات الدفعة',
                      child: Column(
                        crossAxisAlignment:
                            CrossAxisAlignment.start,
                        children: [
                          const _FieldLabel(
                            text: 'المبلغ',
                            requiredField: true,
                          ),

                          const SizedBox(height: 8),

                          TextFormField(
                            controller:
                                _amountController,
                            enabled:
                                !state.isSubmitting,
                            textAlign:
                                TextAlign.right,
                            keyboardType:
                                const TextInputType
                                    .numberWithOptions(
                              decimal: true,
                            ),
                            inputFormatters: [
                              FilteringTextInputFormatter
                                  .allow(
                                RegExp(
                                  r'[0-9٠-٩.,٫]',
                                ),
                              ),
                            ],
                            onChanged: (value) {
                              context
                                  .read<
                                      CollectionPaymentFormBloc>()
                                  .add(
                                    CollectionPaymentAmountChanged(
                                      value,
                                    ),
                                  );
                            },
                            validator: (_) {
                              final amount = context
                                  .read<
                                      CollectionPaymentFormBloc>()
                                  .state
                                  .enteredAmount;

                              if (amount <= 0) {
                                return 'أدخل مبلغاً صحيحاً';
                              }

                              if (amount >
                                  widget.pharmacy
                                      .officialBalance) {
                                return 'المبلغ أكبر من الرصيد الرسمي';
                              }

                              return null;
                            },
                            decoration:
                                _inputDecoration(
                              hintText: '0',
                              suffixText: 'ر.س',
                              prefixIcon: Icons
                                  .payments_outlined,
                            ),
                          ),

                          const SizedBox(height: 17),

                          const _FieldLabel(
                            text: 'تاريخ الدفعة',
                            requiredField: true,
                          ),

                          const SizedBox(height: 8),

                          _DateField(
                            date: state.paymentDate,
                            enabled:
                                !state.isSubmitting,
                            onTap: () {
                              _selectDate(
                                context,
                                state.paymentDate,
                              );
                            },
                          ),

                          const SizedBox(height: 17),

                          const _FieldLabel(
                            text: 'طريقة الدفع',
                            requiredField: true,
                          ),

                          const SizedBox(height: 8),

                          _PaymentMethodField(
                            value:
                                state.paymentMethod,
                            enabled:
                                !state.isSubmitting,
                            onChanged: (method) {
                              context
                                  .read<
                                      CollectionPaymentFormBloc>()
                                  .add(
                                    CollectionPaymentMethodChanged(
                                      method,
                                    ),
                                  );
                            },
                          ),

                          const SizedBox(height: 17),

                          const _FieldLabel(
                            text: 'ملاحظات',
                            requiredField: false,
                          ),

                          const SizedBox(height: 8),

                          TextFormField(
                            controller:
                                _notesController,
                            enabled:
                                !state.isSubmitting,
                            minLines: 3,
                            maxLines: 5,
                            maxLength: 300,
                            textAlign:
                                TextAlign.right,
                            onChanged: (value) {
                              context
                                  .read<
                                      CollectionPaymentFormBloc>()
                                  .add(
                                    CollectionPaymentNotesChanged(
                                      value,
                                    ),
                                  );
                            },
                            decoration:
                                _inputDecoration(
                              hintText:
                                  'أضف ملاحظات حول الدفعة',
                              prefixIcon:
                                  Icons.notes_outlined,
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 15),

                    _SectionCard(
                      title: 'صورة الوصل',
                      subtitle: 'اختياري',
                      child: _ReceiptSection(
                        imagePath:
                            state.receiptImagePath,
                        enabled:
                            !state.isSubmitting,
                        onCameraPressed: () {
                          _pickReceipt(
                            context,
                            ImageSource.camera,
                          );
                        },
                        onGalleryPressed: () {
                          _pickReceipt(
                            context,
                            ImageSource.gallery,
                          );
                        },
                        onRemovePressed: () {
                          context
                              .read<
                                  CollectionPaymentFormBloc>()
                              .add(
                                const CollectionPaymentReceiptRemoved(),
                              );
                        },
                      ),
                    ),

                    const SizedBox(height: 15),

                    const _AccountingNotice(),

                    const SizedBox(height: 22),

                    SizedBox(
                      height: 53,
                      child: FilledButton.icon(
                        onPressed:
                            state.isSubmitting
                                ? null
                                : () {
                                    _submit(
                                      context,
                                    );
                                  },
                        icon: state.isSubmitting
                            ? const SizedBox(
                                width: 20,
                                height: 20,
                                child:
                                    CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: Colors.white,
                                ),
                              )
                            : const Icon(
                                Icons.save_outlined,
                              ),
                        label: Text(
                          state.isSubmitting
                              ? 'جارٍ حفظ الدفعة...'
                              : 'حفظ الدفعة',
                        ),
                        style:
                            FilledButton.styleFrom(
                          backgroundColor:
                              AppColors.primary,
                          foregroundColor:
                              Colors.white,
                          disabledBackgroundColor:
                              AppColors.primary,
                          disabledForegroundColor:
                              Colors.white,
                          shape:
                              RoundedRectangleBorder(
                            borderRadius:
                                BorderRadius.circular(
                              13,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Future<void> _paymentListener(
    BuildContext context,
    CollectionPaymentFormState state,
  ) async {
    if (state.submitStatus ==
        CollectionPaymentSubmitStatus.failure) {
      ScaffoldMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(
          SnackBar(
            content: Text(
              state.errorMessage ??
                  'تعذر حفظ الدفعة',
            ),
            backgroundColor: AppColors.danger,
          ),
        );

      return;
    }

    if (state.submitStatus ==
            CollectionPaymentSubmitStatus
                .success &&
        state.savedPayment != null) {
      await showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (dialogContext) {
          return AlertDialog(
            icon: const Icon(
              Icons.check_circle,
              color: AppColors.success,
              size: 55,
            ),
            title: const Text(
              'تم تسجيل الدفعة',
              textAlign: TextAlign.center,
            ),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  '${_formatAmount(state.savedPayment!.amount)} ر.س',
                  style: const TextStyle(
                    color: AppColors.textPrimary,
                    fontSize: 22,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  state.savedPayment!.status.label,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: AppColors.warning,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 12),
                const Text(
                  'لن يتغير الرصيد الرسمي إلا بعد اعتماد المفوتر.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color:
                        AppColors.textSecondary,
                    height: 1.5,
                  ),
                ),
              ],
            ),
            actionsAlignment:
                MainAxisAlignment.center,
            actions: [
              FilledButton(
                onPressed: () {
                  Navigator.pop(dialogContext);
                },
                child: const Text('تم'),
              ),
            ],
          );
        },
      );

      if (!context.mounted) {
        return;
      }

      Navigator.pop(
        context,
        state.savedPayment,
      );
    }
  }

  Future<void> _selectDate(
    BuildContext context,
    DateTime initialDate,
  ) async {
    final now = DateTime.now();

    final selectedDate =
        await showDatePicker(
      context: context,
      initialDate:
          initialDate.isAfter(now)
              ? now
              : initialDate,
      firstDate: DateTime(2020),
      lastDate: now,
      helpText: 'اختيار تاريخ الدفعة',
      cancelText: 'إلغاء',
      confirmText: 'اختيار',
    );

    if (!context.mounted ||
        selectedDate == null) {
      return;
    }

    context
        .read<CollectionPaymentFormBloc>()
        .add(
          CollectionPaymentDateChanged(
            selectedDate,
          ),
        );
  }

  Future<void> _pickReceipt(
    BuildContext context,
    ImageSource source,
  ) async {
    try {
      final image =
          await _imagePicker.pickImage(
        source: source,
        imageQuality: 80,
        maxWidth: 1600,
      );

      if (!context.mounted ||
          image == null) {
        return;
      }

      context
          .read<CollectionPaymentFormBloc>()
          .add(
            CollectionPaymentReceiptChanged(
              image.path,
            ),
          );
    } catch (_) {
      if (!context.mounted) {
        return;
      }

      ScaffoldMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(
          const SnackBar(
            content: Text(
              'تعذر اختيار صورة الوصل',
            ),
          ),
        );
    }
  }

  void _submit(BuildContext context) {
    FocusScope.of(context).unfocus();

    final isValid =
        _formKey.currentState?.validate() ??
            false;

    if (!isValid) {
      return;
    }

    context
        .read<CollectionPaymentFormBloc>()
        .add(
          const CollectionPaymentSubmitted(),
        );
  }
}

class _PharmacyCard extends StatelessWidget {
  const _PharmacyCard({
    required this.pharmacy,
  });

  final CollectionPharmacyModel pharmacy;

  @override
  Widget build(BuildContext context) {
    return _SectionContainer(
      child: Row(
        children: [
          const CircleAvatar(
            backgroundColor:
                AppColors.primarySoft,
            child: Icon(
              Icons.local_pharmacy_outlined,
              color: AppColors.primary,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                Text(
                  pharmacy.name,
                  style: const TextStyle(
                    color:
                        AppColors.textPrimary,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  pharmacy.area,
                  style: const TextStyle(
                    color:
                        AppColors.textSecondary,
                    fontSize: 11,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _BalanceSection extends StatelessWidget {
  const _BalanceSection({
    required this.officialBalance,
    required this.expectedBalance,
  });

  final double officialBalance;
  final double expectedBalance;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: _BalanceCard(
            title: 'الرصيد الرسمي',
            amount: officialBalance,
            color: AppColors.primary,
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: _BalanceCard(
            title: 'الرصيد المتوقع',
            amount: expectedBalance,
            color: expectedBalance < 0
                ? AppColors.danger
                : AppColors.success,
          ),
        ),
      ],
    );
  }
}

class _BalanceCard extends StatelessWidget {
  const _BalanceCard({
    required this.title,
    required this.amount,
    required this.color,
  });

  final String title;
  final double amount;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return _SectionContainer(
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              color: AppColors.textSecondary,
              fontSize: 10,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            '${_formatAmount(amount)} ر.س',
            style: TextStyle(
              color: color,
              fontWeight: FontWeight.w900,
              fontSize: 15,
            ),
          ),
        ],
      ),
    );
  }
}

class _SectionCard extends StatelessWidget {
  const _SectionCard({
    required this.title,
    required this.child,
    this.subtitle,
  });

  final String title;
  final String? subtitle;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return _SectionContainer(
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  title,
                  style: const TextStyle(
                    color:
                        AppColors.textPrimary,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
              if (subtitle != null)
                Text(
                  subtitle!,
                  style: const TextStyle(
                    color:
                        AppColors.textSecondary,
                    fontSize: 10,
                  ),
                ),
            ],
          ),
          const SizedBox(height: 17),
          child,
        ],
      ),
    );
  }
}

class _SectionContainer
    extends StatelessWidget {
  const _SectionContainer({
    required this.child,
  });

  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(17),
        border: Border.all(
          color: AppColors.border,
        ),
      ),
      child: child,
    );
  }
}

class _FieldLabel extends StatelessWidget {
  const _FieldLabel({
    required this.text,
    required this.requiredField,
  });

  final String text;
  final bool requiredField;

  @override
  Widget build(BuildContext context) {
    return Text.rich(
      TextSpan(
        children: [
          TextSpan(text: text),
          if (requiredField)
            const TextSpan(
              text: ' *',
              style: TextStyle(
                color: AppColors.danger,
              ),
            ),
        ],
      ),
      style: const TextStyle(
        color: AppColors.textPrimary,
        fontWeight: FontWeight.w700,
      ),
    );
  }
}

class _DateField extends StatelessWidget {
  const _DateField({
    required this.date,
    required this.enabled,
    required this.onTap,
  });

  final DateTime date;
  final bool enabled;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: enabled ? onTap : null,
      child: InputDecorator(
        decoration: _inputDecoration(
          prefixIcon:
              Icons.calendar_month_outlined,
        ),
        child: Text(
          _formatDate(date),
        ),
      ),
    );
  }
}

class _PaymentMethodField
    extends StatelessWidget {
  const _PaymentMethodField({
    required this.value,
    required this.enabled,
    required this.onChanged,
  });

  final CollectionPaymentMethod value;
  final bool enabled;
  final ValueChanged<CollectionPaymentMethod>
      onChanged;

  @override
  Widget build(BuildContext context) {
    return DropdownButtonFormField<
        CollectionPaymentMethod>(
      initialValue: value,
      decoration: _inputDecoration(
        prefixIcon:
            Icons.credit_card_outlined,
      ),
      items: CollectionPaymentMethod.values
          .map(
            (method) => DropdownMenuItem(
              value: method,
              child: Text(method.label),
            ),
          )
          .toList(),
      onChanged: enabled
          ? (method) {
              if (method != null) {
                onChanged(method);
              }
            }
          : null,
    );
  }
}

class _ReceiptSection
    extends StatelessWidget {
  const _ReceiptSection({
    required this.imagePath,
    required this.enabled,
    required this.onCameraPressed,
    required this.onGalleryPressed,
    required this.onRemovePressed,
  });

  final String? imagePath;
  final bool enabled;
  final VoidCallback onCameraPressed;
  final VoidCallback onGalleryPressed;
  final VoidCallback onRemovePressed;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        if (imagePath != null)
          Stack(
            children: [
              ClipRRect(
                borderRadius:
                    BorderRadius.circular(14),
                child: Image.file(
                  File(imagePath!),
                  width: double.infinity,
                  height: 185,
                  fit: BoxFit.cover,
                ),
              ),
              PositionedDirectional(
                top: 8,
                end: 8,
                child: IconButton.filled(
                  onPressed: enabled
                      ? onRemovePressed
                      : null,
                  icon: const Icon(Icons.close),
                  style: IconButton.styleFrom(
                    backgroundColor:
                        AppColors.danger,
                    foregroundColor:
                        Colors.white,
                  ),
                ),
              ),
            ],
          )
        else
          const Padding(
            padding: EdgeInsets.all(22),
            child: Column(
              children: [
                Icon(
                  Icons.receipt_long_outlined,
                  color:
                      AppColors.textSecondary,
                  size: 42,
                ),
                SizedBox(height: 9),
                Text(
                  'لم تتم إضافة صورة وصل',
                  style: TextStyle(
                    color:
                        AppColors.textSecondary,
                  ),
                ),
              ],
            ),
          ),

        const SizedBox(height: 12),

        Row(
          children: [
            Expanded(
              child: OutlinedButton.icon(
                onPressed: enabled
                    ? onCameraPressed
                    : null,
                icon: const Icon(
                  Icons.camera_alt_outlined,
                ),
                label: const Text('الكاميرا'),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: OutlinedButton.icon(
                onPressed: enabled
                    ? onGalleryPressed
                    : null,
                icon: const Icon(
                  Icons.photo_library_outlined,
                ),
                label: const Text('المعرض'),
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class _AccountingNotice
    extends StatelessWidget {
  const _AccountingNotice();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.warningSoft,
        borderRadius: BorderRadius.circular(15),
        border: Border.all(
          color: AppColors.warning,
        ),
      ),
      child: const Row(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          Icon(
            Icons.info_outline,
            color: AppColors.warning,
          ),
          SizedBox(width: 10),
          Expanded(
            child: Text(
              'الرصيد المتوقع مؤقت وغير محاسبي. لن يتغير الرصيد الرسمي إلا بعد اعتماد الدفعة من المفوتر.',
              style: TextStyle(
                color:
                    AppColors.textSecondary,
                height: 1.6,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

InputDecoration _inputDecoration({
  String? hintText,
  String? suffixText,
  IconData? prefixIcon,
}) {
  return InputDecoration(
    hintText: hintText,
    suffixText: suffixText,
    prefixIcon: prefixIcon == null
        ? null
        : Icon(
            prefixIcon,
            color: AppColors.textSecondary,
          ),
    filled: true,
    fillColor: AppColors.background,
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(13),
      borderSide: const BorderSide(
        color: AppColors.border,
      ),
    ),
    focusedBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(13),
      borderSide: const BorderSide(
        color: AppColors.primary,
      ),
    ),
    errorBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(13),
      borderSide: const BorderSide(
        color: AppColors.danger,
      ),
    ),
  );
}

String _formatDate(DateTime date) {
  final localDate = date.toLocal();

  final day =
      localDate.day.toString().padLeft(2, '0');

  final month =
      localDate.month.toString().padLeft(2, '0');

  return '$day/$month/${localDate.year}';
}

String _formatAmount(double amount) {
  return amount.toStringAsFixed(
    amount == amount.roundToDouble() ? 0 : 2,
  );
}