import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:project_2/Core/di/injection_container.dart';
import 'package:project_2/Features/auth/bloc/collection_payments_history_bloc.dart';
import 'package:project_2/Features/auth/bloc/collection_payments_history_event.dart';
import 'package:project_2/collection_home_screen.dart';

class CollectionDashboardFeaturePage extends StatelessWidget {
  const CollectionDashboardFeaturePage({
    required this.onRecordPayment,
    required this.onOpenHistory,
    super.key,
  });

  final Future<void> Function() onRecordPayment;
  final Future<void> Function() onOpenHistory;

  @override
  Widget build(BuildContext context) {
    return BlocProvider<CollectionPaymentsHistoryBloc>(
      create: (_) => sl<CollectionPaymentsHistoryBloc>()
        ..add(
          const CollectionPaymentsHistoryRequested(),
        ),
      child: CollectionDashboardPage(
        onRecordPayment: onRecordPayment,
        onOpenHistory: onOpenHistory,
      ),
    );
  }
}