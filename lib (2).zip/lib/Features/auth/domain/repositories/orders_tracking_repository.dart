import 'package:project_2/Features/auth/data/models/order_details_model.dart';

import '../../data/models/tracked_order_model.dart';

abstract class OrdersTrackingRepository {
  Future<List<TrackedOrderModel>> getOrders();

  Future<OrderDetailsModel> getOrderDetails(
    String orderNumber,
  );
}